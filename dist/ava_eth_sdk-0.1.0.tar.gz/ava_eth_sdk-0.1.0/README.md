


The package is on PyPi. You can pip install it:

`pip install ava-protocol-sdk`


